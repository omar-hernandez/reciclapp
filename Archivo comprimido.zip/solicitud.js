function solicitud(){
    var infosolicitud
    
    infosolicitud = document.getElementById("kg").value;
    console.log(infosolicitud)

}