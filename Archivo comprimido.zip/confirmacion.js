function funcionconfU(){
    var dia = "13";
    var mes = "Febrero";
    var horario = "7 a 9";
    var domicilio = "Alvaro Obregón 168";
    var puntos = 20;

    document.getElementById("diaConfirmacion").innerHTML = dia;
    document.getElementById("mesConfirmacion").innerHTML = mes;
    document.getElementById("horarioConfirmacion").innerHTML = horario;
    document.getElementById("domicilioConfirmacion").innerHTML = domicilio;
    document.getElementById("puntosConfirmacion").innerHTML = puntos;

}