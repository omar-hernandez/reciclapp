function why() {
    var respuesta = "<div class='row justify-content-center'><div class='col-11 white'><h4 class='h5'>De cuánto fue en realidad ?:</h4></div></div><div class='row justify-content-around'><div class='col-2 self-align-start'><input type='text' class='first_input'></div><div class='col-12 espacio'></div></div>";
    document.getElementById('why').innerHTML = respuesta;
  }
  function why1() {
    var respuesta = "<div class='row justify-content-center'><div class='col-11 white'><h4 class='h5'>De qué fue el material ?:</h4></div></div><div class='row justify-content-around'><div class='col-2 self-align-start'><input type='text' class='first_input'></div><div class='col-12 espacio'></div></div>";
    document.getElementById('why1').innerHTML = respuesta;
  }